"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "motion/react";
import { useVisitorData } from "@fingerprint/react";
import SignalPortrait from "./SignalPortrait";
import SignalsPanel from "./SignalsPanel";
import { type IdentifyResult, type SmartSignal, seedFromId } from "@/lib/signals";
import { isEnabled, playResolve, playTick, setEnabled } from "@/lib/audio";

const hasPublicKey = !!process.env.NEXT_PUBLIC_FINGERPRINT_PUBLIC_KEY;
type Sim = "auto" | "human" | "bot";

export default function Experience() {
  const { getData } = useVisitorData({ immediate: false });
  const [result, setResult] = useState<IdentifyResult | null>(null);
  const [started, setStarted] = useState(false);
  const [resolved, setResolved] = useState(false);
  const [pulse, setPulse] = useState(0);
  const [sound, setSound] = useState(false);
  const [sim, setSim] = useState<Sim>("auto");
  const [target, setTarget] = useState<[number, number] | null>(null);
  const running = useRef(false);

  async function reveal(kind: "human" | "bot") {
    if (running.current) return;
    running.current = true;
    setStarted(true);
    if (kind === "bot") setSim("bot");
    if (isEnabled()) playResolve();

    if (!hasPublicKey) {
      finish(base({ visitorId: "demo-mode", note: "Demo mode — add NEXT_PUBLIC_FINGERPRINT_PUBLIC_KEY to identify this device." }));
      return;
    }
    try {
      const { visitor_id, event_id } = await getData();
      let enriched: Partial<IdentifyResult> = {};
      try {
        const res = await fetch("/api/identify", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ eventId: event_id }),
        });
        enriched = await res.json();
      } catch { /* soft-fail */ }
      finish(base({
        visitorId: enriched.visitorId ?? visitor_id ?? null,
        confidence: enriched.confidence ?? null,
        enriched: !!enriched.enriched,
        signals: enriched.signals ?? [],
        suspect: enriched.suspect ?? 0,
        bot: enriched.bot ?? false,
        ipCity: enriched.ipCity ?? null,
        ipCountry: enriched.ipCountry ?? null,
        raw: enriched.raw,
        note: enriched.note,
      }));
    } catch {
      finish(base({ visitorId: null, note: "Identification unavailable — check your public key and region." }));
    }
  }

  function finish(r: IdentifyResult) {
    setResult(r);
    setResolved(true);
    if (isEnabled()) playResolve();
  }

  // once the panel is on screen, measure it and hand the particle bridge a target
  useEffect(() => {
    if (!resolved) return;
    const id = requestAnimationFrame(() => {
      const el = document.getElementById("signals-panel");
      if (!el) return;
      const r = el.getBoundingClientRect();
      const cx = ((r.left + 24) / window.innerWidth) * 2 - 1;
      const cy = -(((r.top + r.height / 2) / window.innerHeight) * 2 - 1);
      setTarget([cx, cy]);
    });
    return () => cancelAnimationFrame(id);
  }, [resolved]);

  const onSignalHover = useCallback(() => { setPulse((p) => p + 1); playTick(); }, []);
  function toggleSound() { const n = !sound; setSound(n); setEnabled(n); if (n && resolved) playResolve(); }
  function pick(m: Sim) { setSim((c) => (c === m ? "auto" : m)); setPulse((p) => p + 1); if (isEnabled()) playResolve(); }

  const botActive = sim === "bot" || (sim === "auto" && !!result?.bot);
  const displaySuspect = botActive ? 1 : sim === "human" ? 0 : result?.suspect ?? 0;
  const display: IdentifyResult | null = result
    ? { ...result, bot: botActive, suspect: displaySuspect, signals: withBot(result.signals, botActive) }
    : null;
  const seed = seedFromId(result?.visitorId ?? "awaiting-signal");

  return (
    <main className="stage">
      <SignalPortrait className="portrait" seed={seed} revealed={resolved} bot={botActive} suspect={displaySuspect} pulse={pulse} target={target} />

      <div className="overlay">
        <motion.header
          className="hero" key={botActive ? "bot" : "human"}
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          {botActive ? (
            <>
              <span className="eyebrow small-caps">Fingerprint · AI agent detection</span>
              <h1 className="title">Nice try, <span className="accent">robot</span>.</h1>
              <p className="sub">
                You read as automation — the one visitor we don&apos;t roll out the carpet for.
                This is what a corrupted signal looks like. Humans only past here. 🤖
              </p>
            </>
          ) : (
            <>
              <span className="eyebrow small-caps">Fingerprint · device intelligence</span>
              <h1 className="title">This is <span className="accent">your device</span>,<br />computed in real time.</h1>
              <p className="sub">
                Every visitor is unique and identifiable — even anonymous ones. Reveal the
                signature we compute from your browser.
              </p>
            </>
          )}
          {!started && (
            <div className="cta-wrap">
              <button className="cta" onClick={() => reveal("human")}>
                Show your fingerprint <span className="cta-arrow">→</span>
              </button>
              <button className="cta-ghost" onClick={() => reveal("bot")}>or visit as an AI agent</button>
            </div>
          )}
        </motion.header>

        {resolved && <SignalsPanel result={display} loading={false} onSignalHover={onSignalHover} />}
      </div>

      {resolved && (
        <div className="controls">
          <div className="sim mono">
            <span className="sim-label">simulate</span>
            <button className={sim === "human" ? "on" : ""} onClick={() => pick("human")}>human</button>
            <button className={sim === "bot" ? "on" : ""} onClick={() => pick("bot")}>bot</button>
          </div>
          <button className="sound-toggle mono" onClick={toggleSound} aria-pressed={sound}>
            {sound ? "◼ sound on" : "▶ sound"}
          </button>
        </div>
      )}
    </main>
  );
}

function base(partial: Partial<IdentifyResult>): IdentifyResult {
  return {
    visitorId: null, confidence: null, enriched: false, signals: [],
    suspect: 0, bot: false, ipCity: null, ipCountry: null, ...partial,
  };
}
function withBot(signals: SmartSignal[], botActive: boolean): SmartSignal[] {
  if (!botActive) return signals;
  return [{ key: "bot", label: "Automation", value: true, tone: "warn" }, ...signals.filter((s) => s.key !== "bot")];
}
