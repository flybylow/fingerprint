"use client";

import { useState } from "react";
import { motion } from "motion/react";
import type { IdentifyResult } from "@/lib/signals";
import { shortId } from "@/lib/signals";

type Props = {
  result: IdentifyResult | null;
  loading: boolean;
  onSignalHover: () => void;
};

const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07, delayChildren: 0.1 } },
};
const item = {
  hidden: { opacity: 0, y: 8 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const } },
};

export default function SignalsPanel({ result, loading, onSignalHover }: Props) {
  const [showRaw, setShowRaw] = useState(false);

  return (
    <motion.aside
      id="signals-panel"
      className="panel"
      variants={stagger}
      initial="hidden"
      animate={result ? "show" : "hidden"}
    >
      <motion.div variants={item} className="panel-row">
        <span className="label">Visitor ID</span>
        <span className="mono id">{loading ? "identifying…" : shortId(result?.visitorId ?? null)}</span>
      </motion.div>

      <motion.div variants={item} className="panel-row">
        <span className="label">Confidence</span>
        <span className="mono">
          {result?.confidence != null ? `${(result.confidence * 100).toFixed(1)}%` : "—"}
        </span>
      </motion.div>

      {(result?.ipCity || result?.ipCountry) && (
        <motion.div variants={item} className="panel-row">
          <span className="label">Location</span>
          <span className="mono">{[result?.ipCity, result?.ipCountry].filter(Boolean).join(", ")}</span>
        </motion.div>
      )}

      <motion.div variants={item} className="divider" />

      <motion.div variants={item} className="label small-caps">Smart Signals</motion.div>
      <div className="chips">
        {(result?.signals ?? placeholderSignals).map((s) => (
          <motion.div
            key={s.key}
            variants={item}
            className={`chip chip-${s.tone}`}
            onMouseEnter={onSignalHover}
          >
            <span className="dot" />
            <span>{s.label}</span>
            <span className="chip-val mono">
              {s.value === null ? "—" : s.value ? "yes" : "no"}
            </span>
          </motion.div>
        ))}
      </div>

      {result && !result.enriched && (
        <motion.p variants={item} className="note">
          {result.note ?? "Add a secret key for live Smart Signals."}
        </motion.p>
      )}

      {result?.raw != null && (
        <motion.div variants={item} className="raw">
          <button className="raw-toggle mono" onClick={() => setShowRaw((v) => !v)}>
            {showRaw ? "− hide raw event" : "+ raw event (for engineers)"}
          </button>
          {showRaw && (
            <pre className="raw-pre mono">{JSON.stringify(result.raw, null, 2)}</pre>
          )}
        </motion.div>
      )}
    </motion.aside>
  );
}

const placeholderSignals = [
  { key: "bot", label: "Automation", value: null, tone: "neutral" as const },
  { key: "incognito", label: "Incognito", value: null, tone: "neutral" as const },
  { key: "vpn", label: "VPN", value: null, tone: "neutral" as const },
  { key: "proxy", label: "Proxy", value: null, tone: "neutral" as const },
  { key: "tampering", label: "Tampering", value: null, tone: "neutral" as const },
];
