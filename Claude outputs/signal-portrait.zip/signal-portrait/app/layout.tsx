import type { Metadata } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import { FingerprintProvider } from "@fingerprint/react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Signal Portrait — your device, computed live",
  description:
    "An interactive demo of Fingerprint device intelligence: your visitor identity rendered as a living WebGL signal field.",
};

const apiKey = process.env.NEXT_PUBLIC_FINGERPRINT_PUBLIC_KEY || "demo";
const region = (process.env.NEXT_PUBLIC_FINGERPRINT_REGION || "eu") as "us" | "eu" | "ap";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable} antialiased`}>
      <body>
        <FingerprintProvider apiKey={apiKey} region={region}>
          {children}
        </FingerprintProvider>
      </body>
    </html>
  );
}
