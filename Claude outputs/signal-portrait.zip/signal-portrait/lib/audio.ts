// Minimal, tasteful WebAudio. Off by default, created lazily on a user gesture
// (correct autoplay handling). All sounds are short and low-amplitude — B2B, not toy.

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let ambient: { stop: () => void } | null = null;
let enabled = false;

function ensure(): boolean {
  if (typeof window === "undefined") return false;
  if (!ctx) {
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") ctx.resume().catch(() => {});
  return true;
}

export function setEnabled(on: boolean) {
  enabled = on;
  if (on) {
    ensure();
    startAmbient();
  } else {
    stopAmbient();
  }
}

export function isEnabled() {
  return enabled;
}

/** Soft sub-bass + air on the identify "resolve" moment. */
export function playResolve() {
  if (!enabled || !ensure() || !ctx || !master) return;
  const now = ctx.currentTime;

  const osc = ctx.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(140, now);
  osc.frequency.exponentialRampToValueAtTime(52, now + 0.5);
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(0.5, now + 0.03);
  g.gain.exponentialRampToValueAtTime(0.0001, now + 0.9);
  osc.connect(g).connect(master);
  osc.start(now);
  osc.stop(now + 1.0);

  // a breath of filtered noise
  const dur = 0.5;
  const buf = ctx.createBuffer(1, ctx.sampleRate * dur, ctx.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.value = 1800;
  const ng = ctx.createGain();
  ng.gain.value = 0.08;
  src.connect(lp).connect(ng).connect(master);
  src.start(now);
}

/** Faint tick on chip hover. */
export function playTick() {
  if (!enabled || !ensure() || !ctx || !master) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  osc.type = "triangle";
  osc.frequency.value = 520;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(0.12, now + 0.004);
  g.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);
  osc.connect(g).connect(master);
  osc.start(now);
  osc.stop(now + 0.1);
}

function startAmbient() {
  if (!ensure() || !ctx || !master || ambient) return;
  const now = ctx.currentTime;
  const o1 = ctx.createOscillator();
  const o2 = ctx.createOscillator();
  o1.type = "sine"; o2.type = "sine";
  o1.frequency.value = 55; o2.frequency.value = 55.4; // slow beating
  const lp = ctx.createBiquadFilter();
  lp.type = "lowpass"; lp.frequency.value = 400;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, now);
  g.gain.exponentialRampToValueAtTime(0.05, now + 2.0); // fade in, very low
  // slow swell
  const lfo = ctx.createOscillator();
  lfo.frequency.value = 0.07;
  const lfoG = ctx.createGain();
  lfoG.gain.value = 0.02;
  lfo.connect(lfoG).connect(g.gain);
  o1.connect(lp); o2.connect(lp);
  lp.connect(g).connect(master);
  o1.start(now); o2.start(now); lfo.start(now);
  ambient = {
    stop: () => {
      const t = ctx!.currentTime;
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
      [o1, o2, lfo].forEach((o) => o.stop(t + 0.7));
    },
  };
}

function stopAmbient() {
  if (ambient) { ambient.stop(); ambient = null; }
}
